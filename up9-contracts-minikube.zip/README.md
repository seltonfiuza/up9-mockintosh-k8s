# UP9 Artifacts for `minikube`
This folder contains contract documentation, tests and mocks for `minikube`.



### File structure 
- [contracts](contracts) - generated OpenAPI Specification (Swagger) json files
- [tests](tests) - generated Test code
- [mocks](mocks) - generated Mock instructions

## Contact
Email us at info@up9.com
