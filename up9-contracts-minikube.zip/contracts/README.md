# UP9 Contract Documentation

This directory contains generated OpenAPI Specifications, created by [UP9](https://up9.com).

Each file contains the specification for one service.

## File structure
Each file is a valid OpenAPI Specification 3.0 (aka Swagger) correspondes to a Service infered by UP9.

## Contact
Email us at info@up9.com
