from up9lib import *
from authentication import authenticate

# logging.basicConfig(level=logging.DEBUG)

